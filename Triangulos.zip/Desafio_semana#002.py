def tipo_triangulo(a, b, c):
    if a <= 0 or b <= 0 or c <= 0:
        return "Inválido"
    elif a + b <= c or a + c <= b or b + c <= a:
        return "Inválido"
    elif a == b == c:
        return "Equilátero"
    elif a == b or a == c or b == c:
        return "Isósceles"
    else:
        return "Escaleno"

def main():
    print("Digite os comprimentos dos lados do triângulo:")
    a = float(input("Lado 1: "))
    b = float(input("Lado 2: "))
    c = float(input("Lado 3: "))

    tipo = tipo_triangulo(a, b, c)
    print("O triângulo é:", tipo)

if __name__ == "__main__":
    main()
